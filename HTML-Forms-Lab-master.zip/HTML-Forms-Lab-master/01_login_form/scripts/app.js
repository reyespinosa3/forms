console.log("Sanity Check: JS is working!");

$(document).ready(function(){

  // code in here

});
